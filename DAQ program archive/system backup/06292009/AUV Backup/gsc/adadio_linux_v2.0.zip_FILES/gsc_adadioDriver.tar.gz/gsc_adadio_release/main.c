/***
***  main.c
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***
***     This file is not necessary to compile application programs, therefore
***     should NOT be included in binary only driver distributions.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillan (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.18+, Red Hat distribution, Intel hardware.
***
***/

//////////////////////////////////////////////////////////////////////////
// set the following flag to trace interrupt debug messages.
#ifdef DEBUG
#define TRACE_INTS TRUE
#endif

#define __NO_VERSION__
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"
#include "adadio_ioctl.h"
#include "internals.h"
#include "plx_regs.h"

MODULE_LICENSE("GPL");

#define DEFAULT_TIMEOUT MSECS_TO_SLEEP(5000)

struct board_entry boards_supported[] = {
    {GSC_SUBVENDOR,0x2370,"adadio",GSC_ADADIO},
    {0,0,"NULL",0},               /* null terminated list.... */
};

/* Driver Version */
static const char device_version[] = "$Date: " __DATE__ " " __TIME__ " $";

/* module load/unload functions */
int init_module(void);
void cleanup_module(void);

/* local functions */
int device_write(struct file *, const char *, size_t, loff_t *);
int device_read(struct file *, char *, size_t, loff_t *);
int device_open(struct inode *, struct file *);
int device_close(struct inode *, struct file *);

int device_read_buffer(struct device_board *device, char *buf, int nsamp, int noblock);

int device_read_dma(struct device_board *device, int nsamples);

#ifdef DEBUG
    u32 int_other_count[MAX_BOARDS];
    u32 int_count[MAX_BOARDS];
    u32 dma_count[MAX_BOARDS];
    u32 channel_irq[MAX_BOARDS];
    u32 channel_expected[MAX_BOARDS];
    int board_type[MAX_BOARDS];
    void * context[MAX_BOARDS];
#endif

//#ifdef DEBUG
/************************************************************************/
/* regdump - debug only                                                 */
/************************************************************************/
void regdump(struct device_board *device,char * label)
{
    int q;

    for (q=0;q<=12;q++)
    {
        printk(KERN_INFO GSC_NAME "(%d - %s): register %.2d (addr %.2X) value: %.8x\n", device->minor, label, q, q*4,readlocal(device,q));
    }
    printk(KERN_INFO GSC_NAME "(%d - %s)                 IntCntrlStat: %.8X \n", device->minor, label,readl(IntCntrlStat(device)));
    printk(KERN_INFO GSC_NAME "(%d - %s)                   DMA status: %.8X \n", device->minor, label,readl(DMACmdStatus(device)));
    printk(KERN_INFO GSC_NAME "(%d - %s)                     DMA Mode: %.8X \n", device->minor, label,readl(DMAMode0(device)));
    for (q=0;q<=12;q++)
    {
        printk("%.8X ",device->dma_data[RX].intermediateBuffer[q]);
    }
    printk("\n----------------------------------\n");

}
//#endif

/************************************************************************/
/* timeout_handler                                                      */
/************************************************************************/
void timeout_handler(unsigned long ptr)
{
    struct device_board *device = (struct device_board *) ptr;
    int i;

#ifdef TRACE_INTS
    writel(0xAaaaaaaa, (Mailbox0(device)));
#endif
    printk(KERN_INFO GSC_NAME "(%d): ERROR - device timeout - Debug state: %d\n", device->minor,device->debug_state);
    regdump(device,"timeout " );
    device ->timeout=TRUE;

    // wake up whatever was waiting.
    printk("timeout -> plx int %.8X board control %.8X DMA status %.8X \n",
        readl(IntCntrlStat(device)), readlocal(device,BOARD_CTRL_REG),
        readl(DMACmdStatus(device)));
    printk("DMA Mode %.8X\n",readl(DMAMode0(device)));
    printk("Firm rev %.8X DMA event # %d\n",readlocal(device,0x3c/4),EVENT_DMA_PENDING);

    for(i=0;i<=EVENT_LAST_IRQ_EVENT;i++)
    {
        //printk(KERN_ERR GSC_NAME "(%d): ERROR - event %d status %d\n", device->minor, i,atomic_read(&device->irq_event_pending[i]));
        if (atomic_read(&device->irq_event_pending[i]))
        {
            printk(KERN_ERR GSC_NAME "(%d): ERROR - event %d timeout\n", device->minor, i);
            atomic_set(&device->irq_event_pending[i],FALSE);
            wake_up(device->event_queue_waiting[i]);
        }
    }

    printk(KERN_ERR GSC_NAME "(%d): End timeout handler\n", device->minor);
}

/*************************************************/
#define CLEAR_SPURIOUS_PLX(regval,mask, desc)  { \
    if (regval & mask) \
{ \
    writel((regval & ~mask), IntCntrlStat(device)); \
} \
}
/*printk(KERN_INFO GSC_NAME "(%d): Unexpected interrupt %s %.8lX %.8X %.8X\n",device->minor,desc, regval,mask,~mask); \*/

/************************************************************************/
/* Interrupt handler                                                    */
/************************************************************************/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
irqreturn_t device_interrupt(int irq, void *dev_id, struct pt_regs *regs)
#else
void device_interrupt(int irq, void *dev_id, struct pt_regs *regs)
#endif
{
    struct device_board *device = (struct device_board *)dev_id;
    u32 plxreg;
    u32 localreg;
    u32 dmareg;
    int handled;
    int local_irq;

    handled = FALSE;

#ifdef TRACE_INTS
    //printk(KERN_INFO GSC_NAME " Interrupt()\n");
    writel(0x11111111, (Mailbox0(device)));
#endif

    // determine if the interrupt is enabled.

    plxreg = readl(IntCntrlStat(device));
    if (((plxreg & IRQ_PCI_ENABLE) ==0) ||
        (((plxreg & IRQ_DMA_0_ACTIVE)==0)&&((plxreg & IRQ_LOCAL_ACTIVE))==0)) 
    { // not ours 
        //printk(KERN_INFO GSC_NAME "Interrupt not ours...\n");
#ifdef TRACE_INTS
        writel(0x12121212, (Mailbox0(device)));
        int_other_count[device->board_index]++;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
        return IRQ_NONE;
#else
        return;             
#endif
    }

    // disable the PCI interrupt.

    DisableIrqPlx(device);

    // deal with local interrupt sources.

    localreg = readlocal(device,BOARD_CTRL_REG);
#ifdef TRACE_INTS
    writel(0x13131313, (Mailbox0(device)));
    printk(KERN_INFO GSC_NAME "(%d): our Interrupt! plx: %.8X BCR: %.8X\n", device->minor,plxreg,localreg);
#endif

    // check for DMA complete interrupt
    if (atomic_read(&device->irq_event_pending[EVENT_DMA_PENDING])) {
#ifdef TRACE_INTS
        printk(KERN_INFO GSC_NAME "(%d): IRQ DMA in progress...\n",device->minor);
#endif
        dmareg = readl(DMACmdStatus(device));
        if (dmareg & DMA0_DONE) {
#ifdef TRACE_INTS
        printk(KERN_INFO GSC_NAME "(%d): DMA in progress: %d PLX int/ctrl %.8X BC %.8X DMA status %.8X DMA mode %.8X\n", device->minor,atomic_read(&device->irq_event_pending[EVENT_DMA_PENDING]), readl(IntCntrlStat(device)), readlocal(device,BOARD_CTRL_REG),readl(DMACmdStatus(device)),readl(DMAMode0(device)));
            dma_count[device->board_index]++;
       
            {
                int q;
                for(q=0;q<10;q++)
                {
                    printk("%.8X ", device->dma_data[RX].intermediateBuffer[q]);
                }
                printk("\n");
            }
#endif
            handled = TRUE;
            // ack interrupt 
            writel((dmareg | DMA0_CLR_INT), DMACmdStatus(device));
            writel((DMA0_CLR_INT), DMACmdStatus(device)); 

            // wake up process blocked in 'read()'
            atomic_set(&device->irq_event_pending[EVENT_DMA_PENDING],FALSE);
            wake_up(device->event_queue_waiting[EVENT_DMA_PENDING]);
        }
    }
    else    // check for and clear spurious DMA interrupts...
    {
        plxreg = readl(DMACmdStatus(device));
        if (plxreg & DMA0_ENABLE) {
            // wipe out the DMA1 bits while here, better safe than sorry.
            printk(KERN_INFO GSC_NAME "(%d): Unexpected interrupt DMA0_ENABLE\n",device->minor); 
            writel((DMA0_CLR_INT|DMA1_CLR_INT), DMACmdStatus(device)); 
        }
    }

    // check for local interrupt

    localreg = readlocal(device,BOARD_CTRL_REG);
#ifdef TRACE_INTS
    printk(KERN_INFO GSC_NAME "(%d): plx: %.8X board control %.8X \n", device->minor,plxreg,localreg);
#endif

    
    DisableIrqLocalAll(device);

    // check for local interrupt

    if (localreg & BCR_IRQ_REQUEST_FLAG) {
        // see which kind of event is this.  The hardware is assumed to only have one
        // interrupt active at a time.
#ifdef TRACE_INTS
        int_count[device->board_index]++;
#endif

        local_irq=((localreg>>BCR_INT_SOURCE_SHIFT) & BCR_INT_SOURCE_MASK) ; 

#ifdef TRACE_INTS
        printk(KERN_INFO GSC_NAME "(%d): local IRQ # %d\n", device->minor,local_irq);
#endif
        if (atomic_read(&device->irq_event_pending[local_irq])) {
#ifdef TRACE_INTS
            writel(0x14141414, (Mailbox0(device)));
#endif
            atomic_set(&device->irq_event_pending[local_irq],FALSE);
            wake_up(device->event_queue_waiting[local_irq]);
            handled = TRUE;
        }
        else
        {
#ifdef TRACE_INTS
            writel(0x15151515, (Mailbox0(device)));
#endif
            printk(KERN_ERR GSC_NAME "(%d): disabled irq on device%p\n", device->minor, device);
        }
    }

  



        //printk(KERN_INFO DEVICE_NAME "(%d): Local!\n",device->minor);

        /* see which kind of event is this */
/*
        switch (localreg) {

        case BCR_IRQ_INIT:
#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_INIT %p\n", device->minor,device);
#endif
            if (device->init_pending) {
                device->init_pending = FALSE;
                wake_up(&device->ioctlwq);
            }
            break;

        case BCR_IRQ_AUTOCAL_COMPLETE:
#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): BCR_IRQ_AUTOCAL_COMPLETE %p\n", device->minor,device);
#endif
            device->calibStatus=AUTOCAL_PASSED;
            if (device->autocal_pending) {
                device->autocal_pending = FALSE;
                wake_up(&device->ioctlwq);
            }
            break;

        case BCR_IRQ_OUT_BUFFER_EMPTY:
#ifdef DEBUG
            //printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_OUT_BUFFER_EMPTY %p\n", device->minor,device);
#endif
            if (device->out_buffer_empty_pending) {
                device->out_buffer_empty_pending = FALSE;
                wake_up(&device->ioctlwq);
            }
            break;

        case BCR_IRQ_OUT_BUFFER_LOW_QUARTER:
#ifdef DEBUG
            //printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_OUT_BUFFER_LOW_QUARTER %p\n", device->minor,device);
#endif
            if (device->out_buffer_low_quarter_pending) {
                device->out_buffer_low_quarter_pending = FALSE;
                wake_up(&device->ioctlwq);
            }
            break;

        case BCR_IRQ_OUT_BUFFER_HIGH_QUARTER:
#ifdef DEBUG
            //printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_OUT_BUFFER_HIGH_QUARTER %p\n", device->minor,device);
#endif
            if (device->out_buffer_high_quarter_pending) {
                device->out_buffer_high_quarter_pending = FALSE;
                wake_up(&device->ioctlwq);
            }
            break;

        case BCR_IRQ_BURST_TRIGGER_READY:
#ifdef DEBUG
            //printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_BURST_TRIGGER_READY %p\n", device->minor,device);
#endif
            if (device->burst_trigger_pending) {
                device->burst_trigger_pending = FALSE;
                wake_up(&device->ioctlwq);
            }
            break;

        case BCR_IRQ_LOAD_READY:
#ifdef DEBUG
            //printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_LOAD_READY %p\n", device->minor,device);
#endif
            if (device->load_ready_pending) {
                device->load_ready_pending = FALSE;
                wake_up(&device->writewq);
            }
            break;

        case BCR_IRQ_END_LOAD_READY:
#ifdef DEBUG
            //printk(KERN_INFO DEVICE_NAME "(%d): irq BCR_IRQ_END_LOAD_READY %p\n", device->minor,device);
#endif
            if (device->end_load_ready_pending) {
                device->end_load_ready_pending = FALSE;
                wake_up(&device->writewq);
            }
            break;

        default:
            //printk(KERN_INFO DEVICE_NAME "(%d): unknown Local interrupt %.8lX\n",device->minor,localreg);
            writel(0, IntCntrlStat(device));
            break;
        } // switch
    }
    */


    DisableIrqPlx(device);
    /*
    *   check every possible interrupt source, to ensure that the
    * current interrupt is turned off, expected or not.
    * commented out are at times expected.
    */

    // PLX interrupt-control registers.
    CLEAR_SPURIOUS_PLX(plxreg,IRQ_LOCAL_LSERR_ABORT, "IRQ_LOCAL_LSERR_ABORT*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_LOCAL_LSERR_ABORT, "IRQ_LOCAL_LSERR_ABORT*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_LOCAL_LSERR_OVERFLOW, "IRQ_LOCAL_LSERR_OVERFLOW*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_GENERATE_SERR, "IRQ_GENERATE_SERR*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_MAILBOX_ENABLE, "IRQ_MAILBOX_ENABLE*");
    //  CLEAR_SPURIOUS_PLX(plxreg, IRQ_PCI_ENABLE, "IRQ_PCI_ENABLE*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_PCI_DOORBELL_ENABLE, "IRQ_PCI_DOORBELL_ENABLE*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_ABORT_ENABLE, "IRQ_ABORT_ENABLE*");
    //  CLEAR_SPURIOUS_PLX(plxreg, IRQ_LOCAL_PCI_ENABLE, "IRQ_LOCAL_PCI_ENABLE*");
    //  CLEAR_SPURIOUS_PLX(plxreg, IRQ_LOCAL_ENABLE, "IRQ_LOCAL_ENABLE*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_LOCAL_DOORBELL_ENABLE, "IRQ_LOCAL_DOORBELL_ENABLE*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_DMA_1_ENABLE,"IRQ_DMA_1_ENABLE*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_LOCAL_DOORBELL_ACTIVE,"IRQ_LOCAL_DOORBELL_ACTIVE*");
    CLEAR_SPURIOUS_PLX(plxreg, IRQ_DMA_1_ACTIVE,"IRQ_DMA_1_ACTIVE*");

    //printk(KERN_INFO GSC_NAME " (%d): end IRQ: %d PLX int/ctrl %.8X BC %.8X DMA status %.8X DMA mode %.8X\n", device->minor,device->dma_pending, readl(IntCntrlStat(device)), readlocal(device,BOARD_CTRL_REG),readl(DMACmdStatus(device)),readl(DMAMode0(device)));

    if(!handled)
    {
#ifdef TRACE_INTS
        writel(0x16161616, (Mailbox0(device)));
#endif
      printk(KERN_INFO GSC_NAME "(%d): >>>>>>>>>>>>>Unhandled interrupt - disabling\n", device->minor);
      DisableIrqLocalAll(device);
      DisableIrqPlx(device);
      timeout_handler((unsigned long)device);

    }
#ifdef TRACE_INTS
    writel(0x22222222, (Mailbox0(device)));
    printk(KERN_INFO GSC_NAME "(%d): End IRQ handler\n", device->minor);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    return IRQ_HANDLED;
#else
    return;             
#endif
}
