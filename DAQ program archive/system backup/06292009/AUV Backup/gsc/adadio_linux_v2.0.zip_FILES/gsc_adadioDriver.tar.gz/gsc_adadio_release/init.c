/***
*** init.c  
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***     
***     This file is not necessary to compile application programs, therefore 
***     should NOT be included in binary only driver distributions.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillman (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.x, Red Hat distribution, Intel hardware.
***/

//////////////////////////////////////////////////////////////////////////
// set the following flag to trace debug messages in this module.
#ifdef DEBUG
#define TRACE_INIT TRUE
#endif

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>
#include <linux/version.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"
#include "adadio_ioctl.h"
#include "internals.h"

#include "plx_regs.h"

/* local module data */
static struct file_operations device_fops = {
    open:    device_open,
    release: device_close,
    read:    device_read,
    write:   device_write,
    ioctl:   device_ioctl
};

static int device_major = 0;                  /* device major number (dynamically assigned) */
static struct device_board *boards = 0;       /* linked list of all boards found */

__s8    built[32];
int     num_boards;
int     proc_enabled;

/************************************************************************/
/* module initalization: detect card(s) and set up descriptor(s)        */
/************************************************************************/
int init_module(void)
{
    int index = 0;
    unsigned short reg;
    struct device_board *device, *devicenext;
    struct pci_dev *pdev=NULL;
    struct proc_dir_entry*  proc;
    int i;
    int found;

    sprintf(built, "%s, %s ", __DATE__, __TIME__);
    printk(KERN_INFO GSC_NAME ": driver ( version: %s) built %s loading on kernel %s\n",  DRIVER_VERSION, built, UTS_RELEASE);
    printk(KERN_INFO GSC_NAME ": Copyright (C) 2001-2004 General Standards Corp. \n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,74)
    PCI_DEVICE_LOOP(pdev) {
#else
    while((pdev = pci_find_device(PCI_VENDOR_ID_PLX, PCI_ANY_ID, pdev))) {
#endif
#if TRACE_INIT
        //printk(KERN_INFO GSC_NAME ": Checking...vendor: %X device: %X subvendor: %X subsystem: %X\n",pdev->vendor, pdev->device, pdev->subsystem_vendor, pdev->subsystem_device);
#endif
        if ((pdev->vendor == PCI_VENDOR_ID_PLX) && (pdev->device == PCI_DEVICE_ID_PLX_9080)) {

            /* determine if this is one of the boards supported. */

            found=0;
            i=0;
            while(boards_supported[i].subsystem_device != 0){
                if ((boards_supported[i].subsystem_device == pdev->subsystem_device) &&
                    (boards_supported[i].subsystem_vendor == pdev->subsystem_vendor)){
                        found=1;
                        //printk(KERN_INFO GSC_NAME ":     found board %s type %d\n",boards_supported[i].name,i);
                    }
                    if (found) break;
                    i++;
            }

            if (found){
                printk(KERN_INFO GSC_NAME ":     installing board %s type %d\n",boards_supported[i].name,i);
                pci_read_config_word(pdev, 0x2E, &reg);
                //printk(KERN_INFO GSC_NAME ":     config reg=0x%x\n", reg);
                //printk(KERN_INFO GSC_NAME ":     attaching board #%d\n", index + 1);
                device = (struct device_board *)kmalloc(sizeof(struct device_board), GFP_KERNEL);
                memset(device,0,sizeof(device));
                device ->board_type = i;
                {
                    int ResourceCount = 0;

                    for (i = 0; i < PCI_NUM_BARS; ++i)
                    {
                        // Verify the address is valid
                        if (pci_resource_start(
                            pdev,
                            i
                            ) == 0)
                        {
                            continue;
                        }

                        //printk(KERN_INFO GSC_NAME "   Resource %02d\n", ResourceCount);

                        // Increment resource count
                        ResourceCount++;
                        // Get PCI physical address
                        device->PciBar[i].Physical.QuadPart =
                            pci_resource_start(
                            pdev,
                            i
                            );

                        // Determine resource type
                        if (pci_resource_flags(
                            pdev,
                            i
                            ) & IORESOURCE_IO)
                        {
                            //printk(KERN_INFO GSC_NAME "     Type     : I/O Port\n");

                            // Make sure flags are cleared properly
                            device->PciBar[i].Physical.QuadPart &= ~(0x3);
                            device->PciBar[i].IsIoMapped         = TRUE;
                        }
                        else
                        {
                            //printk(KERN_INFO GSC_NAME "     Type     : Memory Space\n");

                            // Make sure flags are cleared properly
                            device->PciBar[i].Physical.QuadPart &= ~(0xf);
                            device->PciBar[i].IsIoMapped         = FALSE;
                        }

                        //printk(KERN_INFO GSC_NAME "     Address  : %08x\n",device->PciBar[i].Physical.u.LowPart);

                        // Get the size
                        device->PciBar[i].Size = 4096; /*
                                                       Plx_pci_resource_len(
                                                       device,
                                                       i
                                                       );*/
                   }
                }

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,4,0)
                device->runtime_addr = (u32 *)ioremap(pdev->base_address[0], 4096);
                device->ioctlwq = NULL;
                device->readwq = NULL;
                device->writewq = NULL;
                device->dmawq = NULL;
                if (device->PciBar[2].IsIoMapped)
                {
                    //device->local_addr = pdev->resource[2];
                    printk(KERN_ERR GSC_NAME ": I/O mapped local registers\n");
                    device->local_addr = base_address[2];
                }
                else
                {
                    device->local_addr = (u32 *)ioremap(pdev->resource[2].start, 4096);
                }
#else
                if (device->PciBar[2].IsIoMapped)
                {
                    device->local_addr = (u32 *)pdev->resource[2].start;
                }
                else
                {
                    device->local_addr = (u32 *)ioremap(pdev->resource[2].start, 4096);
                }
                device->runtime_addr = (u32 *)ioremap(pdev->resource[0].start, pci_resource_len(pdev, 0));
                init_waitqueue_head(&device->ioctlwq);
                init_waitqueue_head(&device->readwq);
                init_waitqueue_head(&device->writewq);
                init_waitqueue_head(&device->dmawq);
#endif
                device->pdev = pdev;
                device->fillBuffer=FALSE;
                device->irqlevel = pdev->irq;
                device->busy = 0;
                device->minor = index;
                device->next = boards;
#ifdef DEBUG
                printk(KERN_INFO GSC_NAME ":     base_address[0]=0x%lX, base_address[2]=0x%lX\n",pdev->resource[0].start, pdev->resource[2].start);
                //              printk(KERN_INFO GSC_NAME ":     local_addr=%p, runtime_addr=%p irq=%d\n", device->local_addr, device->runtime_addr, device->irqlevel);
#endif
                boards = device;
                device->board_index=index;
#ifdef TRACE_INIT
                context[index]=device;
                board_type[index]=device->board_type;
#endif
                index++;
                num_boards++;
            }
        }
    }
    if (index == 0) {
        printk(KERN_ERR GSC_NAME ": no board found\n");
        return (-ENODEV);
    }
    device_major = register_chrdev(0, GSC_NAME, &device_fops);
    if (device_major < 0) {
        /* OK, could not register -- undo the work we have done above */
        printk(KERN_ERR GSC_NAME ": could not register device number\n");
        for (device = boards; device; device = devicenext) {
            devicenext = device->next;
            iounmap(device->local_addr);
            iounmap(device->runtime_addr);
            kfree(device);
        }
        boards = NULL;
        return (-ENODEV);
    }
    /*
    *   Add /proc file system support.
    */

    if (num_boards)
    {
        remove_proc_entry(GSC_NAME, NULL);  /* Just in case. */
        proc    = create_proc_entry(GSC_NAME, S_IRUGO, NULL);

        if (proc)
        {
            proc_enabled    = 1;
            proc->read_proc = read_proc;
            proc->get_info  = (void*)proc_get_info;
        }
        else
        {
            printk( "<1>%s: create_proc_entry() failure.\n",
                GSC_NAME);
            cleanup_module();
        }
    }

#ifdef TRACE_INIT
    printk(KERN_INFO GSC_NAME ": major=%d\n", device_major);
    {
        int j;
        for (j=0;j<MAX_BOARDS;j++){
            int_other_count[j]=0;
            int_count[j]=0;
            dma_count[j]=0;
            channel_irq[j]=0;
        }
    }
#endif
    return 0;
}

/************************************************************************/
/* cleanup when unloading module                                        */
/************************************************************************/
void cleanup_module(void)
{
    struct device_board *device, *devicenext;
    unregister_chrdev(device_major, GSC_NAME);
    for (device = boards; device; device = devicenext) {
        devicenext = device->next;
        iounmap(device->local_addr);
        iounmap(device->runtime_addr);
        kfree(device);
    }
    if (proc_enabled)   {
        remove_proc_entry(GSC_NAME, NULL);
        proc_enabled    = 0;
    }

    boards = NULL;
    //printk(KERN_INFO GSC_NAME ": unloaded\n");
}

/************************************************************************/
/* open device                                                          */
/************************************************************************/
int device_open(struct inode *inode, struct file *fp)
{
    struct device_board *device;
    u32 regval;
    for (device = boards; device; device = device->next) {
        if (MINOR(inode->i_rdev) == device->minor) {
            if (device->busy) {
                printk(KERN_INFO GSC_NAME "(%d): board already opened\n", device->minor);
                return (-EBUSY);
            }
            //printk(KERN_INFO GSC_NAME "(%d): opening board\n", device->minor);
            if (request_irq(device->irqlevel, (void *) device_interrupt, SA_SHIRQ, GSC_NAME, device) < 0) {
                printk(KERN_INFO GSC_NAME "(%d): cannot get interrupt %d\n", device->minor, device->irqlevel);
                device->busy = 0;
                return (-EBUSY);
            }
            if (!(device->dma_data[RX].intermediateBuffer = (u32 *)__get_dma_pages(GFP_KERNEL, DMA_ORDER))) {
                printk(KERN_INFO GSC_NAME "(%d): can not allocate DMA pages\n", device->minor);
                free_irq(device->irqlevel, device);
                device->busy = 0;
                return (-EBUSY);
            }
#ifdef TRACE_INIT
            //memset(device->intermediateBuffer,0xa5,DMA_ORDER*PAGE_SIZE);
#endif
            device->dma_data[RX].intermediatePhysicalAddr = virt_to_phys((void *)device->dma_data[RX].intermediateBuffer);
#ifdef TRACE_INIT
            printk(KERN_INFO GSC_NAME "(%d): DMA virt=%p, phys=0x%x size %d\n", device->minor, device->dma_data[RX].intermediateBuffer, device->dma_data[RX].intermediatePhysicalAddr, sizeof(device->dma_data[RX].intermediateBuffer));
#endif
            init_timer(&device->watchdog_timer);
            device->timeout_seconds=20;
            device->watchdog_timer.function=timeout_handler;
            device->watchdog_timer.data = (unsigned long) device;
#ifdef DEBUG
            device->nread=0;
            device->last=-1;
#endif
            device->busy = 1;
            device->dma_data[RX].dmaState = DMA_DISABLE;
            device->dma_data[RX].dmastart = FALSE;
            device->dma_data[RX].dmasamples = 0;
            memset(device->irq_event_pending,FALSE,sizeof(device->irq_event_pending));
          
            device->error = ADA_SUCCESS;
            device->signalno = (-1);
            device->signalev = NO_EVENT;
            device->dma_data[RX].intermediateSamples=0;

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,4,0)
            device->ioctlwq = NULL;
            device->readwq = NULL;
            device->writewq = NULL;
            device->dmawq = NULL;
#else
            init_waitqueue_head(&device->ioctlwq);
            init_waitqueue_head(&device->readwq);
            init_waitqueue_head(&device->writewq);
            init_waitqueue_head(&device->dmawq);
#endif

            device->event_queue_waiting[EVENT_INIT]=&device->ioctlwq;
            device->event_queue_waiting[EVENT_AUTOCAL_COMPLETE]=&device->ioctlwq;
            device->event_queue_waiting[EVENT_INPUT_BUFFER_EMPTY]=&device->readwq;
            device->event_queue_waiting[EVENT_INPUT_BUFFER_HALF_FULL]=&device->readwq;
            device->event_queue_waiting[EVENT_INPUT_BUFFER_FULL]=&device->readwq;
            device->event_queue_waiting[EVENT_INPUT_BURST_COMPLETE]=&device->readwq;
            device->event_queue_waiting[EVENT_OUTPUT_STROBE_COMPLETE]=&device->writewq;
            device->event_queue_waiting[EVENT_DMA_PENDING]=&device->dmawq;

            device->debug_state=0;

            sema_init(&device->sem,1);

            fp->private_data = device;
            /* reset DMA engines */
#ifdef TRACE_INIT
            //printk(KERN_INFO GSC_NAME "(%d): resetting DMA engines\n", device->minor);
#endif
            regval = readl(DMACmdStatus(device));
            regval &= STOP_DMA_CMD_0_MASK;
            regval &= STOP_DMA_CMD_1_MASK;
            writel(regval, DMACmdStatus(device));

            // enable bus mastering
            writel(readl(PciLocRemap0(device))|0x04,PciLocRemap0(device));

            // reset local IRQ flag 
#ifdef TRACE_INIT
            //printk(KERN_INFO GSC_NAME "(%d): resetting local IRQ flag\n", device->minor);
#endif
            // disable local interrupts 
            DisableIrqLocalAll(device);

#ifdef TRACE_INIT
            printk(KERN_INFO GSC_NAME "(%d): device_open done\n", device->minor);
#endif
            MOD_INC_USE_COUNT;
            return (0);
        }
    }
    printk(KERN_INFO GSC_NAME "(%d): can not find board\n", MINOR(inode->i_rdev));
    return (-ENODEV);
}

/************************************************************************/
/* close device                                                         */
/************************************************************************/
int device_close(struct inode *inode, struct file *fp)
{
    struct device_board *device = (struct device_board *)fp->private_data;
    u32 regval;
#ifdef TRACE_INIT
    printk(KERN_INFO GSC_NAME "(%d): closing board\n", device->minor);
#endif
    DisableIrqPlx(device);
    /* reset DMA engines */
    regval = readl(DMACmdStatus(device));
    regval &= STOP_DMA_CMD_0_MASK;
    regval &= STOP_DMA_CMD_1_MASK;
    writel(regval, DMACmdStatus(device));
    /* reset local IRQ flag */
    DisableIrqLocalAll(device);
    /* free resources */
    free_irq(device->irqlevel, device);
    free_pages((u32)device->dma_data[RX].intermediateBuffer, DMA_ORDER);
    device->busy = 0;
    MOD_DEC_USE_COUNT;
    return (0);
}

//module_init(init_module);
//module_exit(cleanup_module);

//EXPORT_SYMBOL(built);
