/***
*** hardware.c  
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***     
***     This file is not necessary to compile application programs, therefore 
***     should NOT be included in binary only driver distributions.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillman (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.x, Red Hat distribution, Intel hardware.
***/

//////////////////////////////////////////////////////////////////////////
// set the following flag to trace interrupt debug messages.
#ifdef DEBUG
#define TRACE_HARDWARE TRUE
#endif

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"
#include "adadio_ioctl.h"
#include "internals.h"

#include "plx_regs.h"

/************************************************************************/
/*                                                                      */
/************************************************************************/
void DisableIrqPlx(struct device_board *device)
{
    writel(readl(IntCntrlStat(device)) & ~(IRQ_PCI_ENABLE | IRQ_DMA_0_ENABLE | IRQ_LOCAL_PCI_ENABLE), IntCntrlStat(device));
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
void EnableIrqPlxLocal(struct device_board *device)
{
    writel(readl(IntCntrlStat(device)) | IRQ_PCI_ENABLE | IRQ_LOCAL_PCI_ENABLE, IntCntrlStat(device));
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
void EnableIrqPlxDMA(struct device_board *device)
{
    writel(readl(IntCntrlStat(device)) | IRQ_PCI_ENABLE | IRQ_DMA_0_ENABLE /*|PCI_INT_ENABLE*/, IntCntrlStat(device));
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
void DisableIrqLocalAll(struct device_board *device)
{
    u32 regval;

    regval = readlocal(device,BOARD_CTRL_REG);
    regval &= (~(BCR_INT_SOURCE_MASK<<BCR_INT_SOURCE_SHIFT));
    regval &= ~BCR_IRQ_REQUEST_FLAG;
    writelocal(device,regval,BOARD_CTRL_REG);
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
void EnableIrqLocal(struct device_board *device, u32 irq)
{
    u32 regval;

    regval = readlocal(device,BOARD_CTRL_REG);
    regval &= (~(BCR_INT_SOURCE_MASK<<BCR_INT_SOURCE_SHIFT));
    regval |= irq<<BCR_INT_SOURCE_SHIFT;
    writelocal(device,regval,BOARD_CTRL_REG);
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
void DisableIrqLocal(struct device_board *device, u32 irq)
{
    u32 regval;

    regval = readlocal(device,BOARD_CTRL_REG);
    regval &= (~(BCR_INT_SOURCE_MASK<<BCR_INT_SOURCE_SHIFT));
    writelocal(device,regval,BOARD_CTRL_REG);
}

/************************************************************************/
/* writelocal                                                           */
/*                                                                      */
/* Write to the board local registers, whether the local registers      */
/* are in I/O space or memory space.                                    */
/*                                                                      */
/*                                                                      */
/************************************************************************/
void writelocal(struct device_board *device, unsigned value, unsigned address)
{
    if (device->PciBar[2].IsIoMapped) /* i/o space */
    {
        //printk(KERN_INFO GSC_NAME "writelocal I/O space addr: %.8X value: %.8X.\n",address,value);
        outl(value, (unsigned) device->local_addr+address*4);
    }
    else
    {
        writel(value, device->local_addr+address);
    }
};

/************************************************************************/
/* readlocal                                                            */
/*                                                                      */
/* Read from the board local registers, whether the local registers     */
/* are in I/O space or memory space.                                    */
/*                                                                      */
/*                                                                      */
/************************************************************************/
unsigned readlocal(struct device_board *device, unsigned address)
{
    if (device->PciBar[2].IsIoMapped) /* i/o space */
    {
        //      printk(KERN_INFO GSC_NAME "readlocal I/O space addr: %.8X \n",address);
        return inl((unsigned)device->local_addr+address*4);
    }
    else
    {
        return readl(device->local_addr+address);
    }
    return 0;
};

