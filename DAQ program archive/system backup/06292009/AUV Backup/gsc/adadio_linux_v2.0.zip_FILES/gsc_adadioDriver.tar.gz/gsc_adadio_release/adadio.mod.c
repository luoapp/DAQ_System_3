#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

#undef unix
struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = __stringify(KBUILD_MODNAME),
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{        0, "cleanup_module" },
	{        0, "init_module" },
	{        0, "struct_module" },
	{        0, "__mod_timer" },
	{        0, "autoremove_wake_function" },
	{        0, "malloc_sizes" },
	{        0, "remove_proc_entry" },
	{        0, "sprintf" },
	{        0, "jiffies" },
	{        0, "__might_sleep" },
	{        0, "del_timer_sync" },
	{        0, "put_user_size" },
	{        0, "printk" },
	{        0, "pci_find_device" },
	{        0, "__down_failed_interruptible" },
	{        0, "__ioremap" },
	{        0, "__cond_resched" },
	{        0, "kmem_cache_alloc" },
	{        0, "pci_bus_read_config_word" },
	{        0, "__get_free_pages" },
	{        0, "request_irq" },
	{        0, "schedule" },
	{        0, "register_chrdev" },
	{        0, "create_proc_entry" },
	{        0, "free_pages" },
	{        0, "__wake_up" },
	{        0, "get_user_size" },
	{        0, "kfree" },
	{        0, "prepare_to_wait" },
	{        0, "iounmap" },
	{        0, "unregister_chrdev" },
	{        0, "finish_wait" },
	{        0, "__up_wakeup" },
	{        0, "free_irq" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";

