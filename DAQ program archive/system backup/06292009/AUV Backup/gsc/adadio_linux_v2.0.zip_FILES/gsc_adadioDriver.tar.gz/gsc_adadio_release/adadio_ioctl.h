/***
*** adadio_ioctl.h 
***
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO family of 
***     16-bit analog output boards. This file is part of the Linux
***     driver source distribution for this board.
***     
***  Copyrights (c):
***     General Standards Corporation (GSC), 2003-2004
***
***  Author:
***     Evan Hillman (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.x, Red Hat distribution, Intel hardware.
***/

#ifndef ADADIO_IOCTL_H_INCLUDED
#define ADADIO_IOCTL_H_INCLUDED

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

/*
 *  IOCTL defines
 */

#define IOCTL_ADADIO                           's'

#define IOCTL_GSC_NO_COMMAND            _IO(IOCTL_ADADIO, 1)
#define IOCTL_GSC_READ_REGISTER         _IOWR(IOCTL_ADADIO, 2, struct register_params)   
#define IOCTL_GSC_WRITE_REGISTER        _IOWR(IOCTL_ADADIO, 3, struct register_params)
#define IOCTL_GSC_GET_DEVICE_ERROR      _IOR(IOCTL_ADADIO, 4,  unsigned long)
#define IOCTL_GSC_SET_TIMEOUT           _IOW(IOCTL_ADADIO, 5,  unsigned long)
#define IOCTL_GSC_SET_DMA_MODE          _IOW(IOCTL_ADADIO, 6,  unsigned long)
#define IOCTL_GSC_CONFIG_INPUTS         _IOW(IOCTL_ADADIO, 7,  unsigned long)
#define IOCTL_GSC_SELECT_LOOPBACK_CHANNEL _IOW(IOCTL_ADADIO, 8,  unsigned long)
#define IOCTL_GSC_CALIBRATE             _IOW(IOCTL_ADADIO,  9, unsigned long)
#define IOCTL_GSC_SET_DATA_FORMAT       _IOW(IOCTL_ADADIO, 10, unsigned long)
#define IOCTL_GSC_SET_INPUT_BUFFER_SIZE _IOW(IOCTL_ADADIO, 11, unsigned long)
#define IOCTL_GSC_ENABLE_OUTPUTS        _IOW(IOCTL_ADADIO, 12, unsigned long)
#define IOCTL_GSC_ENABLE_STROBE         _IOW(IOCTL_ADADIO, 13, unsigned long)
#define IOCTL_GSC_STROBE_OUTPUTS        _IO(IOCTL_ADADIO, 14)
#define IOCTL_GSC_TRIGGER_INPUTS        _IOW(IOCTL_ADADIO, 15, unsigned long)
#define IOCTL_GSC_INITIALIZE            _IO(IOCTL_ADADIO, 16)  
#define IOCTL_GSC_SET_DIO_DIR           _IOW(IOCTL_ADADIO, 17, unsigned long)
#define IOCTL_GSC_SET_DIO               _IOW(IOCTL_ADADIO, 18, unsigned long)
#define IOCTL_GSC_GET_DIO               _IOR(IOCTL_ADADIO, 19, unsigned long)
#define IOCTL_GSC_SET_DIO_CTRL          _IOW(IOCTL_ADADIO, 20, unsigned long)
#define IOCTL_GSC_GET_DIO_CTRL          _IOW(IOCTL_ADADIO, 21, unsigned long)
#define IOCTL_GSC_SET_NRATE             _IOW(IOCTL_ADADIO, 22, unsigned long)
#define IOCTL_GSC_GET_DEVICE_TYPE       _IOR(IOCTL_ADADIO, 23, unsigned long)
#define IOCTL_GSC_WRITE_ANALOG_0        _IOW(IOCTL_ADADIO, 24, unsigned long)
#define IOCTL_GSC_WRITE_ANALOG_1        _IOW(IOCTL_ADADIO, 25, unsigned long)
#define IOCTL_GSC_WRITE_ANALOG_2        _IOW(IOCTL_ADADIO, 26, unsigned long)
#define IOCTL_GSC_WRITE_ANALOG_3        _IOW(IOCTL_ADADIO, 27, unsigned long)
#define IOCTL_GSC_CLEAR_BUFFER          _IOW(IOCTL_ADADIO, 28, unsigned long)
#define IOCTL_GSC_FILL_INPUT_BUFFER     _IOW(IOCTL_ADADIO, 29, unsigned long)

/*****************************************************************************/
//
// IOCTL_GSC_NO_COMMAND
//
// Parameter = NONE

/*****************************************************************************/
//
// IOCTL_GSC_READ_REGISTER    
// IOCTL_GSC_WRITE_REGISTER    
//
// Parameter = PADA_REGISTER_PARAMS pRegParams;

/*** ADA Registers ***/
#define BOARD_CTRL_REG          0
#define DIGITAL_IO_PORT_REG     1
#define ANALOG_OUTPUT_CHAN0_REG 2
#define ANALOG_OUTPUT_CHAN1_REG 3
#define ANALOG_OUTPUT_CHAN2_REG 4
#define ANALOG_OUTPUT_CHAN3_REG 5
#define ANALOG_INPUT_REG        6
#define SAMPLE_RATE_REG         7
#define LAST_LOCAL_REGISTER     SAMPLE_RATE_REG

typedef struct register_params {
    __u32 eRegister;             // range: see definitions below
    __u32 ulValue;              // range: 0x0-0xFFFFFFFF, same register values below
} REGISTER_PARAMS, *PREGISTER_PARAMS;

/* Masks for the ADA Board Control Register (BCR). */

#define BCR_AIM_MASK                    0x07
#define BCR_AIM_SHIFT                   0

#define BCR_AIM_SINGLE_ENDED_CONTINUOUS 0
#define BCR_AIM_SINGLE_ENDED_BURST      1
#define BCR_AIM_DIFFERENTIAL_CONTINUOUS 2
#define BCR_AIM_DIFFERENTIAL_BURST      3
#define BCR_AIM_LOOPBACK_SELFTEST       4
#define BCR_AIM_VREF_TEST               5
#define BCR_AIM_ZERO_TEST               7

#define BCR_LOOPBACK_MASK               0x03
#define BCR_LOOPBACK_SHIFT              3
#define BCR_LOOPBACK_MAX                0x03

#define BCR_DATA_FORMAT_MASK            1
#define BCR_DATA_FORMAT_SHIFT           6

#define BCR_INPUT_BUFF_SIZE_MASK        0x0f
#define BCR_INPUT_BUFF_SIZE_SHIFT       7
#define BCR_INPUT_BUFF_SIZE_MAX         0x0f

#define BCR_INPUT_BUFFER_CLEAR          (1<<11)

#define BCR_LAST_CHANNEL_MASK           0x07
#define BCR_LAST_CHANNEL_SHIFT          15

#define BCR_ENABLE_OUTPUTS_MASK         0x01
#define BCR_ENABLE_OUTPUTS_SHIFT        18

#define BCR_ENABLE_OUTPUTS_STROBE_MASK  0x01
#define BCR_ENABLE_OUTPUTS_STROBE_SHIFT 19

#define BCR_INPUT_BUFFER_EMPTY_MASK     0x01
#define BCR_INPUT_BUFFER_EMPTY_SHIFT    20

#define BCR_INPUT_BUFFER_HALF_MASK      0x01
#define BCR_INPUT_BUFFER_HALF_SHIFT     21

#define BCR_INPUT_BUFFER_FULL_MASK      0x01
#define BCR_INPUT_BUFFER_FULL_SHIFT     22

#define BCR_INT_SOURCE_MASK             0x07
#define BCR_INT_SOURCE_SHIFT            23

#define BCR_IRQ_INIT                    0
#define BCR_IRQ_AUTOCAL_COMPLETE        1
#define BCR_IRQ_INPUT_BUFFER_EMPTY      2
#define BCR_IRQ_INPUT_BUFFER_HALF_FULL  3
#define BCR_IRQ_INPUT_BUFFER_FULL       4
#define BCR_IRQ_INPUT_BURST_COMPLETE    5
#define BCR_IRQ_OUTPUT_STROBE_COMPLETE  6

#define BCR_IRQ_REQUEST_FLAG            (1<<26)

#define BCR_CAL_MODE_MASK               0x03
#define BCR_CAL_MODE_SHIFT              27
#define BCR_CAL_MODE_NORMAL             0
#define BCR_CAL_MODE_LOAD               1
#define BCR_CAL_MODE_AUTOCAL            2


#define BCR_OUTPUT_STROBE_MASK          (1<<29)

#define BCR_INPUT_TRIGGER_MASK          (1<<30)

#define BCR_INITIALIZE_MASK             (1<<31)

/* Masks for the ADA Digital I/O Port Register (DPR). */
#define DPR_IO_DATA0_MASK        (1<<0)
#define DPR_IO_DATA1_MASK        (1<<1)
#define DPR_IO_DATA2_MASK        (1<<2)
#define DPR_IO_DATA3_MASK        (1<<3)
#define DPR_IO_DATA4_MASK        (1<<4)
#define DPR_IO_DATA5_MASK        (1<<5)
#define DPR_IO_DATA6_MASK        (1<<6)
#define DPR_IO_DATA7_MASK        (1<<7)
#define DPR_IO_DATA_MASK         0xFF
#define DPR_IO_DATA_SHIFT        0
#define DPR_IO_CTRL_INPUT_MASK   0x01
#define DPR_IO_CTRL_INPUT_SHIFT  8
#define DPR_IO_CTRL_OUTPUT_MASK  0x01
#define DPR_IO_CTRL_OUTPUT_SHIFT 9
#define DPR_IO_CTRL_DIR_MASK     0x01
#define DPR_IO_CTRL_DIR_SHIFT    10

/* The masks for the ADA Analog Data Registers (ADR). */
#define ADR_DATA_MASK 0xFFFF

/*** OFFSET BINARY FORMAT ***/
#define OB_MAX_POSITIVE 0xFFFF
#define OB_PLUS_ONE     0x8001
#define OB_ZERO         0x8000
#define OB_MINUS_ONE    0x7FFF
#define OB_MAX_NEGATIVE 0x0000

/*** TWO'S COMPLEMENT FORMAT ***/
#define TC_MAX_POSITIVE 0x7FFF
#define TC_PLUS_ONE     0x0001
#define TC_ZERO         0x0000
#define TC_MINUS_ONE    0xFFFF
#define TC_MAX_NEGATIVE 0x8000


/* The masks for the ADA Sample Rate Register (SRR). */
#define SRR_SAMPLE_RATE_MASK 0xFFFF

/*****************************************************************************/
//
// IOCTL_GSC_GET_DEVICE_ERROR
//
// Parameter = unsigned long * pulDeviceError;
//     RANGE: 0-8

#define ADA_SUCCESS                    0
#define ADA_INVALID_PARAMETER          1
#define ADA_INVALID_BUFFER_SIZE        2
#define ADA_PIO_TIMEOUT                3
#define ADA_DMA_TIMEOUT                4
#define ADA_IOCTL_TIMEOUT              5
#define ADA_OPERATION_CANCELLED        6
#define ADA_RESOURCE_ALLOCATION_ERROR  7
#define ADA_INVALID_REQUEST            8

// aliased to allow code reuse from other driver code bases.

#define DEVICE_SUCCESS              ADA_SUCCESS                    
#define DEVICE_INVALID_PARAMETER    ADA_INVALID_PARAMETER          
#define DEVICE_INVALID_BUFFER_SIZE  ADA_INVALID_BUFFER_SIZE        
#define DEVICE_PIO_TIMEOUT          ADA_PIO_TIMEOUT                
#define DEVICE_DMA_TIMEOUT          ADA_DMA_TIMEOUT                
#define DEVICE_IOCTL_TIMEOUT        ADA_IOCTL_TIMEOUT              
#define DEVICE_OPERATION_CANCELLED  ADA_OPERATION_CANCELLED        
#define DEVICE_RESOURCE_ALLOCATION_ERROR ADA_RESOURCE_ALLOCATION_ERROR  
#define DEVICE_INVALID_REQUEST      ADA_INVALID_REQUEST            

/*****************************************************************************/
//
// IOCTL_GSC_SET_TIMEOUT
//
//  The timeout for read operations, autocal and init functions.
//
// Parameter = unsigned long * pulTimeout;
//     RANGE: 0x0-0xFFFFFFFF
#define MAX_TIMEOUT 0xFFFFFFFF

/*****************************************************************************/
//
// IOCTL_GSC_SET_DMA_MODE
//
// selects if DMA operations are enabled, disabled or demand mode.  Demand mode is
// only available on newer boards - check the hardware user manual.
// Parameter = PINT pbDMAEnable;
enum {
    DMA_DISABLE,
    DMA_ENABLE,
    DMA_DEMAND_MODE
};

/*****************************************************************************/
//
// IOCTL_GSC_CONFIG_INPUTS
//
// Set the input mode.  Applies for all channels.
//
// Parameter = unsigned long *pConfigInput;

// ulAnalogInputMode options
#define SINGLE_ENDED_CONTINUOUS 0
#define SINGLE_ENDED_BURST      1
#define DIFFERENTIAL_CONTINUOUS 2
#define DIFFERENTIAL_BURST      3
#define LOOPBACK_SELFTEST       4
#define VREF_TEST               5
#define ZERO_TEST               7

/*****************************************************************************/
//
// IOCTL_GSC_SELECT_LOOPBACK_CHANNEL
//
// Parameter = unsigned long *pulLoopbackChannel;
//     RANGE: 0-3


/*****************************************************************************/
//
// IOCTL_GSC_CALIBRATE
//
// Parameter = none;

/*****************************************************************************/
//
// IOCTL_GSC_SET_DATA_FORMAT
//
// Parameter = unsigned long *pulFormat;
//     RANGE: 0-1

#define FORMAT_TWOS_COMPLEMENT 0
#define FORMAT_OFFSET_BINARY   1

/*****************************************************************************/
//
// IOCTL_GSC_SET_INPUT_BUFFER_SIZE
//
// Parameter = unsigned long * pulBufferSize;
//     RANGE: 0-15

#define BUF_SIZE_1      0
#define BUF_SIZE_2      1
#define BUF_SIZE_4      2
#define BUF_SIZE_8      3
#define BUF_SIZE_16     4
#define BUF_SIZE_32     5
#define BUF_SIZE_64     6
#define BUF_SIZE_128    7
#define BUF_SIZE_256    8
#define BUF_SIZE_512    9
#define BUF_SIZE_1024  10
#define BUF_SIZE_2048  11
#define BUF_SIZE_4096  12
#define BUF_SIZE_8192  13
#define BUF_SIZE_16384 14
#define BUF_SIZE_32768 15

/*****************************************************************************/
//
// IOCTL_GSC_ENABLE_OUTPUTS
//
// Parameter = unsigned long *pConfigOutput;

// TRUE to enable outputs
// FALSE to disable outputs

/*****************************************************************************/
//
// IOCTL_GSC_ENABLE_STROBE
//
// Parameter = unsigned long *pEnableStrobe;

// TRUE to enable output strobe
// FALSE to disable output strobe

/*****************************************************************************/
//
// IOCTL_GSC_STROBE_OUTPUTS
//
// Initiate an output strobe cycle.
//
// Parameter = NONE

/*****************************************************************************/
//
// IOCTL_GSC_TRIGGER_INPUTS
//
// Initiate an input trigger.
//
// Parameter = NONE

/*****************************************************************************/
//
// IOCTL_GSC_INITIALIZE
//
// Initialize the hardware back to a know state
//
// Parameter = NONE

/*****************************************************************************/
//
// IOCTL_GSC_SET_DIO_DIR
//
// Set the direction of the digital I/O bits 0-7.
//
// Parameter = unsigned long * pulDIODir;
//     RANGE: 0-1

#define DIO_DIR_INPUT  0
#define DIO_DIR_OUTPUT 1

/*****************************************************************************/
//
// IOCTL_GSC_SET_DIO
//
// Parameter = unsigned long * pulDIOValue;
//     RANGE: 0-255

#define DIO_MAX_VALUE 0xFF

/*****************************************************************************/
//
// IOCTL_GSC_GET_DIO
//
// Parameter = unsigned long * pulDIOValue;
//     Returned RANGE: 0-255

/*****************************************************************************/
//
// IOCTL_GSC_SET_DIO_CTRL
//
// Parameter = unsigned long *pbDIOCtrlValue;
//     RANGE: FALSE-TRUE

/*****************************************************************************/
//
// IOCTL_GSC_GET_DIO_CTRL
//
// Parameter = unsigned long *pbDIOCtrlValue;
//     RANGE: FALSE-TRUE

/*****************************************************************************/
//
// IOCTL_GSC_SET_NRATE
//
// Parameter = unsigned long * pulNRate;
//     RANGE: 100-65535 or 0x0064-0xFFFF

// Send in sample rate in samples/second
// to get the Nrate for IOCTL_GSC_SET_NRATE

#define MIN_NRATE 0x00000064
#define MAX_NRATE 0x0000FFFF

/*****************************************************************************/
//
// IOCTL_GSC_GET_DEVICE_TYPE
//
// Parameter = unsigned long * pDeviceType;

/*****************************************************************************/
//
// IOCTL_GSC_WRITE_ANALOG_0
//
// Parameter = unsigned long * pValue;
// Range 0 - MAX_ANALOG_OUT

#define MAX_ANALOG_OUT 0xFFFF /* for all channels */

/*****************************************************************************/
//
// IOCTL_GSC_WRITE_ANALOG_1
//
// Parameter = unsigned long * pValue;
// Range 0 - MAX_ANALOG_OUT

/*****************************************************************************/
//
// IOCTL_GSC_WRITE_ANALOG_2
//
// Parameter = unsigned long * pValue;
// Range 0 - MAX_ANALOG_OUT

/*****************************************************************************/
//
// IOCTL_GSC_WRITE_ANALOG_3
//
// Parameter = unsigned long * pValue;
// Range 0 - MAX_ANALOG_OUT

#endif  /* entire file */

