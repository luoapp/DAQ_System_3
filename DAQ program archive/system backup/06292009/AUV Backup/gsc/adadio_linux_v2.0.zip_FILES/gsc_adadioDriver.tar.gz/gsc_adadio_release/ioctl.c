/***
*** ioctl.c  
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***     
***     This file is not necessary to compile application programs, therefore 
***     should NOT be included in binary only driver distributions.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillman (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.x, 2.6, Red Hat distribution, Intel hardware.
***/

//////////////////////////////////////////////////////////////////////////
// set the following flag to trace debug messages in this module.


#ifndef __KERNEL__
#define __KERNEL__
#endif

#ifdef DEBUG
#define TRACE_IOCTL TRUE
#endif

#define __NO_VERSION__
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"

#include "adadio_ioctl.h"
#include "internals.h"
#include "plx_regs.h"

/* ioctl file operation: this does the bulk of the work */
int device_ioctl(struct inode *inode, struct file *fp, unsigned int num, unsigned long arg)
{
    struct device_board *device = (struct device_board *)fp->private_data;
    struct register_params regs;
    unsigned long regval,ulval;

    /*
    main ioctl function dispatch */
    /* 'break' at the end of branches which need to wait for the */
    /* channels ready condition, 'return' from others */
    switch (num) {
        case IOCTL_GSC_NO_COMMAND:
            return (0);
            break;

        case IOCTL_GSC_READ_REGISTER:
            copy_from_user_ret(&regs, (void *)arg, sizeof(regs), (-EFAULT));
            if ((regs.eRegister < BOARD_CTRL_REG) || (regs.eRegister > LAST_LOCAL_REGISTER)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regs.ulValue = readl(device->local_addr + regs.eRegister);
            copy_to_user_ret((void *)arg, &regs, sizeof(regs), (-EFAULT));
            return (0);
            break;

        case IOCTL_GSC_WRITE_REGISTER:
            copy_from_user_ret(&regs, (void *)arg, sizeof(regs), (-EFAULT));
            if ((regs.eRegister < BOARD_CTRL_REG) || (regs.eRegister > LAST_LOCAL_REGISTER)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            writel(regs.ulValue, device->local_addr + regs.eRegister);
            return (0);
            break;

        case IOCTL_GSC_GET_DEVICE_ERROR:
            put_user_ret(device->error, (unsigned long *)arg, (-EFAULT));
            return (0);
            break;

        case IOCTL_GSC_SET_TIMEOUT:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > MAX_TIMEOUT)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            device->timeout=ulval;
            return (0);
            break;

        case IOCTL_GSC_SET_DMA_MODE:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < DMA_DISABLE) || (ulval > DMA_DEMAND_MODE)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            device->dma_data[RX].dmaState=ulval;
            return (0);
            break;

        case IOCTL_GSC_CONFIG_INPUTS:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < SINGLE_ENDED_CONTINUOUS) || (ulval > ZERO_TEST)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regval = readlocal(device,BOARD_CTRL_REG);
            regval &= ~(BCR_AIM_MASK<<BCR_AIM_SHIFT);
            regval |= (ulval << BCR_AIM_SHIFT);
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_SELECT_LOOPBACK_CHANNEL:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > BCR_LOOPBACK_MAX)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regval = readlocal(device,BOARD_CTRL_REG);
            regval &= ~(BCR_LOOPBACK_MASK<<BCR_LOOPBACK_SHIFT);
            regval |= (ulval << BCR_LOOPBACK_SHIFT);
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_CALIBRATE:
#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): IOCTL calibrating device\n", device->minor);
#endif
            //printk(KERN_INFO DEVICE_NAME "(%d) -------------------------\n", device->minor);
            //printk(KERN_INFO DEVICE_NAME "(%d): calibrating device\n", device->minor);
            writel(readl(IntCntrlStat(device)) | IRQ_PCI_ENABLE | IRQ_LOCAL_PCI_ENABLE, IntCntrlStat(device));

            // set up to receive the autocal done interrupt.
            regval = readlocal(device,BOARD_CTRL_REG);
            //printk(KERN_INFO DEVICE_NAME "(%d): board control %.8X\n", device->minor,readlocal(device,BOARD_CTRL_REG));
            regval &= (~(BCR_INT_SOURCE_MASK<<BCR_INT_SOURCE_SHIFT));
            regval |= BCR_IRQ_AUTOCAL_COMPLETE<<BCR_INT_SOURCE_SHIFT;
            atomic_set(&device->irq_event_pending[EVENT_AUTOCAL_COMPLETE],TRUE);
            writelocal(device,regval,BOARD_CTRL_REG);

            // start the actual autocal

            regval = readlocal(device,BOARD_CTRL_REG);
            regval &=~(BCR_CAL_MODE_MASK<<BCR_CAL_MODE_SHIFT);
            regval |=(BCR_CAL_MODE_AUTOCAL<<BCR_CAL_MODE_SHIFT);
            writelocal(device,regval,BOARD_CTRL_REG);

            device->timeout=FALSE;
            device->watchdog_timer.expires=jiffies+device->timeout_seconds*HZ;
            add_timer(&device->watchdog_timer);

            //printk(KERN_INFO DEVICE_NAME "(%d): board control %.8X\n", device->minor,readlocal(device,BOARD_CTRL_REG));
            //printk(KERN_INFO DEVICE_NAME "(%d): auto cal about to wait\n", device->minor);
            wait_event_interruptible(*device->event_queue_waiting[EVENT_AUTOCAL_COMPLETE],(!atomic_read(&device->irq_event_pending[EVENT_AUTOCAL_COMPLETE])));

            if (device->timeout) {
                printk(KERN_INFO DEVICE_NAME "(%d): timeout when calibrating device\n", device->minor);
                atomic_set(&device->irq_event_pending[EVENT_AUTOCAL_COMPLETE],FALSE);
                device->error = DEVICE_IOCTL_TIMEOUT;
                return (-EIO);
            }
            else
                del_timer_sync(&device->watchdog_timer);

#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): ioctl autocal done\n", device->minor);
#endif
            return (0);
            break;

        case IOCTL_GSC_SET_DATA_FORMAT:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > FORMAT_OFFSET_BINARY)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regval = readlocal(device,BOARD_CTRL_REG);
            regval &= ~(BCR_DATA_FORMAT_MASK<<BCR_DATA_FORMAT_SHIFT);
            regval |= (ulval << BCR_DATA_FORMAT_SHIFT);
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_SET_INPUT_BUFFER_SIZE:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < BUF_SIZE_1) || (ulval > BUF_SIZE_32768)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regval = readlocal(device,BOARD_CTRL_REG);
            regval &= ~(BCR_INPUT_BUFF_SIZE_MASK<<BCR_INPUT_BUFF_SIZE_SHIFT);
            regval |= (ulval << BCR_INPUT_BUFF_SIZE_SHIFT);
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_ENABLE_OUTPUTS:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            regval = readlocal(device,BOARD_CTRL_REG);
            if (ulval)
            {
                regval |= (BCR_ENABLE_OUTPUTS_MASK << BCR_ENABLE_OUTPUTS_SHIFT);
            }
            else
            {
                regval &= ~(BCR_ENABLE_OUTPUTS_MASK << BCR_ENABLE_OUTPUTS_SHIFT);
            }
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_ENABLE_STROBE:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            regval = readlocal(device,BOARD_CTRL_REG);
            if (ulval)
            {
                regval |= (BCR_ENABLE_OUTPUTS_STROBE_MASK << BCR_ENABLE_OUTPUTS_STROBE_SHIFT);
            }
            else
            {
                regval &= ~(BCR_ENABLE_OUTPUTS_STROBE_MASK << BCR_ENABLE_OUTPUTS_STROBE_SHIFT);
            }
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_STROBE_OUTPUTS:
            regval = readlocal(device,BOARD_CTRL_REG);
            regval |= BCR_OUTPUT_STROBE_MASK;
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_TRIGGER_INPUTS:
            regval = readlocal(device,BOARD_CTRL_REG);
            regval |= BCR_INPUT_TRIGGER_MASK;
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_INITIALIZE:
#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): initializing device\n", device->minor);
#endif
            atomic_set(&device->irq_event_pending[EVENT_INIT],TRUE);
            EnableIrqPlxLocal(device);
#ifdef DEBUG
            printk(" (%d): IntCntrlStat - %.8x\n",device->minor, readl(IntCntrlStat(device)));
#endif
            EnableIrqLocal(device,BCR_IRQ_INIT);

            device->timeout=FALSE;
            device->watchdog_timer.expires=jiffies+device->timeout_seconds*HZ;
            add_timer(&device->watchdog_timer);
            regval = readlocal(device,BOARD_CTRL_REG);
            regval |= BCR_INITIALIZE_MASK;
            writelocal(device,regval,BOARD_CTRL_REG);
            //printk(KERN_INFO DEVICE_NAME "(%d): init about to wait\n", device->minor);
            wait_event_interruptible(*device->event_queue_waiting[EVENT_INIT],(!atomic_read(&device->irq_event_pending[EVENT_INIT])));
            if (signal_pending(current)) {
#ifdef TRACE_IOCTL
                printk(KERN_ERR GSC_NAME "(%d): Signal termination...\n", device->minor);
#endif
                del_timer_sync(&device->watchdog_timer);
                DisableIrqPlx(device);
                return (-ERESTARTSYS); 
            }
            if (device->timeout)
            {
                //printk("%ld %ld\n",jiffies, device->watchdog_timer.expires);
                printk(KERN_INFO DEVICE_NAME "(%d): timeout during device initialize\n", device->minor);
                atomic_set(&device->irq_event_pending[EVENT_INIT],FALSE);
                device->error = DEVICE_IOCTL_TIMEOUT;
                return (-EIO);
            }
            else
                del_timer_sync(&device->watchdog_timer);

#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): plx int ctrl %.8X board ctrl %.8X DMA ctrl status%.8X\n",device->minor, readl(IntCntrlStat(device)), readlocal(device,BOARD_CTRL_REG),readl(DMACmdStatus(device)));
            printk(KERN_INFO DEVICE_NAME "(%d): ioctl initialize done\n", device->minor);
#endif

            return (0);
            break;

        case IOCTL_GSC_SET_DIO_DIR:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < DIO_DIR_INPUT) || (ulval > DIO_DIR_OUTPUT)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
           regval = readlocal(device,DIGITAL_IO_PORT_REG);
            if (ulval==DIO_DIR_OUTPUT)
            {
                regval |= (DPR_IO_CTRL_DIR_MASK << DPR_IO_CTRL_DIR_SHIFT);
            }
            else
            {
                regval &= ~(DPR_IO_CTRL_DIR_MASK << DPR_IO_CTRL_DIR_SHIFT);
            }
            writelocal(device,regval,DIGITAL_IO_PORT_REG);
            return (0);
            break;

        case IOCTL_GSC_SET_DIO:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > DIO_MAX_VALUE)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regval = readlocal(device,DIGITAL_IO_PORT_REG);
            regval &= ~(DPR_IO_DATA_MASK << DPR_IO_DATA_SHIFT);
            regval |= (ulval << DPR_IO_DATA_SHIFT);
            writelocal(device,regval,DIGITAL_IO_PORT_REG);
            return (0);
            break;

        case IOCTL_GSC_GET_DIO:
            copy_from_user_ret(&regs, (unsigned long *)arg, sizeof(unsigned long), (-EFAULT));
            regval = readlocal(device,DIGITAL_IO_PORT_REG)&DIO_MAX_VALUE;
            copy_to_user_ret((void *)arg, &regval, sizeof(unsigned long), (-EFAULT));
            return (0);
            break;

        case IOCTL_GSC_SET_DIO_CTRL:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < FALSE) || (ulval > TRUE)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            regval = readlocal(device,DIGITAL_IO_PORT_REG);
            if (ulval==TRUE)
            {
                regval |= (DPR_IO_CTRL_OUTPUT_MASK << DPR_IO_CTRL_OUTPUT_SHIFT);
            }
            else
            {
                regval &= ~(DPR_IO_CTRL_OUTPUT_MASK << DPR_IO_CTRL_OUTPUT_SHIFT);
            }
            writelocal(device,regval,DIGITAL_IO_PORT_REG);
            return (0);
            break;

        case IOCTL_GSC_GET_DIO_CTRL:
            copy_from_user_ret(&regs, (unsigned long *)arg, sizeof(unsigned long), (-EFAULT));
            regval = readlocal(device,DIGITAL_IO_PORT_REG);
            regval>>=DPR_IO_CTRL_INPUT_SHIFT;
            regval&=DPR_IO_CTRL_INPUT_MASK;
            copy_to_user_ret((void *)arg, &regval, sizeof(unsigned long), (-EFAULT));
            return (0);
            break;

        case IOCTL_GSC_SET_NRATE:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < MIN_NRATE) || (ulval > MAX_NRATE)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): IOCTL_GSC_SET_NRATE %lX\n", device->minor,ulval);
           readlocal(device,SAMPLE_RATE_REG);
#endif
           writelocal(device,ulval,SAMPLE_RATE_REG);
#ifdef DEBUG
           readlocal(device,SAMPLE_RATE_REG);
#endif
            return (0);
            break;

        case IOCTL_GSC_GET_DEVICE_TYPE:
            put_user_ret(0, (unsigned long *)arg, (-EFAULT));
            return (0);

        case IOCTL_GSC_WRITE_ANALOG_0:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > MAX_ANALOG_OUT)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            writelocal(device,ulval,ANALOG_OUTPUT_CHAN0_REG);
            return (0);
            break;

        case IOCTL_GSC_WRITE_ANALOG_1:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > MAX_ANALOG_OUT)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            writelocal(device,ulval,ANALOG_OUTPUT_CHAN1_REG);
            return (0);
            break;

        case IOCTL_GSC_WRITE_ANALOG_2:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > MAX_ANALOG_OUT)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            writelocal(device,ulval,ANALOG_OUTPUT_CHAN2_REG);
            return (0);
            break;

        case IOCTL_GSC_WRITE_ANALOG_3:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            if ((ulval < 0) || (ulval > MAX_ANALOG_OUT)) {
                device->error = DEVICE_INVALID_PARAMETER;
                return (-EIO);
            }
            writelocal(device,ulval,ANALOG_OUTPUT_CHAN3_REG);
            return (0);
            break;

        case IOCTL_GSC_CLEAR_BUFFER:
            regval = readlocal(device,BOARD_CTRL_REG);
            regval |= (BCR_INPUT_BUFFER_CLEAR);
            writelocal(device,regval,BOARD_CTRL_REG);
            regval &= (~(BCR_INPUT_BUFFER_CLEAR));
            writelocal(device,regval,BOARD_CTRL_REG);
            return (0);
            break;

        case IOCTL_GSC_FILL_INPUT_BUFFER:
            get_user_ret(ulval, (unsigned long *)arg, (-EFAULT));
            device->fillBuffer=ulval;
            return (0);
            break;

        default:
#ifdef DEBUG
            printk(KERN_INFO DEVICE_NAME "(%d): unknown IOCTL\n", device->minor);
#endif
            return (-EINVAL);
    }
    return (0);			
}
