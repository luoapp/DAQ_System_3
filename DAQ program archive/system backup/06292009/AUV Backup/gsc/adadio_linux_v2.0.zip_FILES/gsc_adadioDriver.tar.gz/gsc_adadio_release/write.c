/***
***  write.c
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***
***     This file is not necessary to compile application programs, therefore
***     should NOT be included in binary only driver distributions.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillan (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.18+, Red Hat distribution, Intel hardware.
***
***/
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"
#include "adadio_ioctl.h"
#include "internals.h"

#include "plx_regs.h"

/************************************************************************/
/* write operation: easy -- just return an error                        */
/************************************************************************/
/* write operation: easy -- just return an error */
int device_write(struct file *fp, const char *buf, size_t size, loff_t * lt)
{
    return (-EPERM);
}
