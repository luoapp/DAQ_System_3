/***
***  read.c
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillman (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.18+, Red Hat distribution, Intel hardware.
***
***/

//////////////////////////////////////////////////////////////////////////
// set the following flag to trace interrupt debug messages.
#ifdef DEBUG
#define TRACE_READ TRUE
#endif

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"
#include "adadio_ioctl.h"
#include "internals.h"

#include "plx_regs.h"
static int FillintermediateBuffer(struct device_board *device, char *buf, u32 nRequested, int noblock);
static int device_read_dma(struct device_board *device, u32 nRequested,int DMAMode);

#define DMA_DEMAND_MODE 100 /* not used in this driver, here for a placeholder */

const int inputBufferSize[]=
{
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
};

/************************************************************************/
/* TransferToUser - be sure not to copy more than there is space in the */
/* user buffer.  Returns bytes transferred                              */
/************************************************************************/
long TransferToUser(struct device_board *device, u32 nRequested)
{
    int bytesRequested;

    // make sure there is space for the data.
    nRequested = min(device->dma_data[RX].userRemaining, nRequested);

    // make sure there is data
    nRequested = min(device->dma_data[RX].intermediateSamples, nRequested);

    // don't transfer more than is in the intermediate buffer.
    nRequested = min(DMA_SIZE, (unsigned long)nRequested);

    // convert to bytes.
    bytesRequested = nRequested * sizeof(ulong);

#ifdef TRACE_READ
    printk(KERN_ERR GSC_NAME "(%d): TransferToUser userRemain %d dma_data[RX].intermediateSamples %d nRequested %d\n",device->minor, device->dma_data[RX].userRemaining,device->dma_data[RX].intermediateSamples, nRequested);
    printk(KERN_ERR GSC_NAME "(%d): TransferToUser dma_data[RX].userOffset %d dma_data[RX].intermediateSamples %d nRequested %d\n",device->minor, device->dma_data[RX].userOffset,device->dma_data[RX].intermediateSamples, nRequested);
#endif
    __copy_to_user(device->dma_data[RX].userBuffer+device->dma_data[RX].userOffset*sizeof(ulong), 
                   &device->dma_data[RX].intermediateBuffer[device->dma_data[RX].intermediateStart], bytesRequested);

    device->dma_data[RX].intermediateStart += nRequested;
    device->dma_data[RX].intermediateSamples -= nRequested;
    device->dma_data[RX].userOffset += nRequested;
    device->dma_data[RX].userRemaining-= nRequested;
#ifdef TRACE_READ
    printk(KERN_ERR GSC_NAME "(%d): TransferToUser userRemain %d dma_data[RX].intermediateSamples %d nRequested %d\n",device->minor, device->dma_data[RX].userRemaining,device->dma_data[RX].intermediateSamples, nRequested);
#endif

    return bytesRequested;
}

/************************************************************************/
/* Transfer data from the intermediate buffer to the user buffer.       */
/* returns bytes transferred                                            */
/************************************************************************/
int ProcessRead(struct device_board *device)
{
    u32 nRequested;
    int retval;
    long bytesCopied;

    nRequested=device->dma_data[RX].userRemaining;

    bytesCopied=0;

    // start by copying what is already in the intermediate buffer.

#ifdef TRACE_READ
    printk(KERN_ERR GSC_NAME "(%d): ProcessRead - residual samples: %d\n", device->minor,device->dma_data[RX].intermediateSamples);
#endif
    // give either what the user requests or what is left in the buffer, whichever is less.
    if (device->dma_data[RX].intermediateSamples > 0) {

#ifdef TRACE_READ
        printk(KERN_INFO GSC_NAME "(%d): ProcessRead - local data copy...\n", device->minor);
#endif
        retval = TransferToUser(device, nRequested);

        // if the user buffer is now full, return.
        if (device->dma_data[RX].userRemaining==0){ // done
            return(retval);
        }

        // if the user does not ask for full buffers, return
        if (!device->fillBuffer) {
            return(retval);
        }

    } // if (device->dma_data[RX].intermediateSamples > 0) 

    // need to get a batch of data from the board.

    // read at most an intermediate buffer full at a time
    if (nRequested > DMA_SAMPLES) {
        nRequested = DMA_SAMPLES;
    }

    do {  // do it over and over if fillBuffer flag set, once otherwise
#ifdef TRACE_READ
        printk(KERN_INFO GSC_NAME "(%d): ProcessRead - looping...remaining: %d fillbuffer %d\n", device->minor,device->dma_data[RX].userRemaining,device->fillBuffer);
#endif
            retval = FillintermediateBuffer(device, device->dma_data[RX].userBuffer+device->dma_data[RX].userOffset*sizeof(u32), 
                nRequested, (device->fp->f_flags & O_NONBLOCK));
            if (retval<0){ // returned error
                return retval;
            }
            if (retval==0) { // got no data
                return (-EAGAIN);
            }
            bytesCopied += TransferToUser(device, retval);
    } while((device->dma_data[RX].userRemaining>0) && device->fillBuffer);
    
#ifdef TRACE_READ
    printk(KERN_ERR GSC_NAME "(%d): ProcessRead - returning: %ld bytes %ld samples\n", device->minor, bytesCopied, bytesCopied/sizeof(long));
#endif
    return (bytesCopied);
}

/************************************************************************/
/* read operation: either polled or uses PLX DMA on CH0                 */
/************************************************************************/
int device_read(struct file *fp, char *buf, size_t size, loff_t * lt)
{
    struct device_board *device = (struct device_board *)fp->private_data;
    u32 nRequested;

    device->fp=fp;
    nRequested = size / sizeof(long);
#ifdef TRACE_READ
    printk(KERN_INFO GSC_NAME "(%d): device_read() data requested: %d %x -------------------%d\n", device->minor,nRequested,nRequested,device->nread);
    device->nread++;
#endif

    // verify parameters 
    if (nRequested <= 0) {
#ifdef TRACE_READ
        printk(KERN_INFO GSC_NAME "(%d): device_read - zero sample return\n", device->minor);
#endif
        return (0);
    }

    if (!access_ok(VERIFY_WRITE, (u32)buf, size)) {
#ifdef TRACE_READ
        printk(KERN_ERR GSC_NAME "(%d): device_read - access not OK\n", device->minor);
#endif
        return (-EFAULT);
    }

    device->dma_data[RX].userOffset=0; // start at the beginning of the user buffer.
    device->dma_data[RX].userRemaining=nRequested;
    device->dma_data[RX].intermediateStart=0;
    device->dma_data[RX].userBuffer=buf;
    return ProcessRead(device);
}

/************************************************************************/
/*  Filldma_data[RX].intermediateBuffer                                              */
/*                                                                      */
/* Buffered I/O read method                                             */
/* The method first attempts to fill the DMA buffer to a "reasonable"   */
/* level                                                                */
/************************************************************************/
static int FillintermediateBuffer(struct device_board *device, char *buf, u32 nRequested, int noblock)
{
    int i/*, threshold*/;
    u32 nToTransfer;
    u32 bufferStatus;
    int samplesInBuffer;

    nToTransfer = min(nRequested,(u32)DMA_SAMPLES);
    device->dma_data[RX].intermediateStart=0;
    device->dma_data[RX].intermediateSamples=0;
    if (down_interruptible(&device->sem)){
        return -ERESTARTSYS;
    }

#if TRACE_READ
    printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer() nRequested %d DMA_SAMPLES %ld\n", device->minor,nRequested,DMA_SAMPLES);
#endif
    switch(device->dma_data[RX].dmaState) {
        // for PIO and regular DMA, wait for sufficient samples
        case DMA_DISABLE: // PIO
        case DMA_ENABLE:

            // enable the interrupt in case the interrupt happens during this window of decision.

#if TRACE_READ
            writel(0x77777777, (Mailbox0(device)));
#endif
            atomic_set(&device->irq_event_pending[EVENT_INPUT_BUFFER_HALF_FULL],TRUE);
            EnableIrqLocal(device, BCR_IRQ_INPUT_BUFFER_HALF_FULL);
#if TRACE_READ
            writel(0x44444444, (Mailbox0(device)));
#endif
//            threshold = readlocal(device, INPUT_BUFFER_CONTROL_REG)&IBCR_THRESHOLD_MASK;
            bufferStatus = readlocal(device, BOARD_CTRL_REG)&(BCR_INPUT_BUFFER_HALF_MASK<<BCR_INPUT_BUFFER_HALF_SHIFT);
#if TRACE_READ
//
//        printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer first Current fifo samples 0x%.8X threshold 0x%.8X\n", device->minor, fifosamples, threshold);
//        while (readlocal(device,BUFFER_SIZE_REG) < threshold)
//           ;       
        
        //printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer after wait fill  threshold 0x%.8X\n", device->minor, threshold);
#endif
            if (bufferStatus == 0) // need more
            {
                // first of all, check for non-blocking I/O.
                if (noblock) {
#if TRACE_READ
                    printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer - return error noblock\n", device->minor);
#endif
                    device->error = ADA_SUCCESS;
                    up (&device->sem);
                    return (-EAGAIN);
                }

                samplesInBuffer=inputBufferSize[(readlocal(device, BOARD_CTRL_REG)>>BCR_INPUT_BUFF_SIZE_SHIFT)&BCR_INPUT_BUFF_SIZE_MASK]/2;
                // see if there is already more data in the input data than the threshold.
#if TRACE_READ
                printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer DMA/PIO wait for more data... 0x%X samples in buffer BCR: %.8X\n", device->minor,samplesInBuffer,readlocal(device, BOARD_CTRL_REG));
#endif
                device->timeout=FALSE;

                device->watchdog_timer.expires=jiffies+device->timeout_seconds*HZ;
                device->debug_state=8;
                add_timer(&device->watchdog_timer);
                writel(0x33333333, (Mailbox0(device)));

                writel(readl(IntCntrlStat(device)) | IRQ_PCI_ENABLE | IRQ_LOCAL_PCI_ENABLE, IntCntrlStat(device));
                up (&device->sem);
                wait_event_interruptible(device->readwq,(!atomic_read(&device->irq_event_pending[EVENT_INPUT_BUFFER_HALF_FULL])));
                if (signal_pending(current)) {
                    device->debug_state=9;
                    del_timer_sync(&device->watchdog_timer);
                    DisableIrqPlx(device);
                    return (-ERESTARTSYS); 
                }
                if (down_interruptible(&device->sem)){
                    return -ERESTARTSYS;
                }
               //threshold = readlocal(device, INPUT_BUFFER_CONTROL_REG)&IBCR_THRESHOLD_MASK;
#if TRACE_READ
                writel(0x55555555, (Mailbox0(device)));
             //   printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer Next threshold %.8X\n", device->minor, threshold);
#endif
                if (device->timeout)
                {
                    device->debug_state=11;
                   printk(KERN_ERR GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer - timeout...\n", device->minor);
                    //printk(" (%d): In progress: %d PLX int/ctrl %.8X BC %.8X DMA %.8X\n", device->minor,device->dma_pending, readl(IntCntrlStat(device)), readlocal(device,BOARD_CTRL_REG),readl(DMACmdStatus(device)));
                    device->error = ADA_PIO_TIMEOUT;
                    up (&device->sem);
                    return (-EIO);
                }
                else
                {
                    device->debug_state=12;
                   del_timer_sync(&device->watchdog_timer);
                   device->debug_state=13;
                }
                if (signal_pending(current)) {
                    return (-ERESTARTSYS); 
                }
                if (device->timeout) {
                    printk(KERN_ERR GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer - timeout error\n", device->minor);
                    device->error = ADA_PIO_TIMEOUT;
                    up (&device->sem);
                    return (-EIO);
                }
                // if still no data present, something is wrong.
            }
            else // don't need to wait for data...
            {
                DisableIrqLocal(device,0);
                atomic_set(&device->irq_event_pending[EVENT_INPUT_BUFFER_HALF_FULL],FALSE);
            }
            break;

            nToTransfer=min(nToTransfer,(u32)samplesInBuffer);
            // for demand mode, wait for the DMA done interrupt.
        case DMA_DEMAND_MODE:

            if (device_read_dma(device, nToTransfer, DMA_DEMAND_MODE)!=0)
            {
                up (&device->sem);
                return (-EAGAIN);
            }
            else
            {
#ifdef TRACE_READ
                printk(KERN_INFO GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer - demand mode success\n", device->minor);
#endif
            };
            break;

        default: // invalid state
            printk(KERN_ERR GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer - invalid state failure\n", device->minor);
            up (&device->sem);
           return (-EIO);
            break;
    } // switch

    // move the data from the hardware buffer to the intermediate buffer by the user's chosen method.
    // don't copy more than the hardware buffer contains.

    switch(device->dma_data[RX].dmaState) {
        case DMA_DISABLE: // PIO
#if TRACE_READ
            printk(KERN_ERR GSC_NAME "(%d): PIO starting addr %p  to transfer %d\n", device->minor,device->dma_data[RX].intermediateBuffer,nToTransfer);
            memset(device->dma_data[RX].intermediateBuffer,0x55, DMA_ORDER*PAGE_SIZE);
#endif

            for (i=0; i< nToTransfer; i++) {
                device->dma_data[RX].intermediateBuffer[i] = readlocal(device,ANALOG_INPUT_REG);
            }
            device->dma_data[RX].intermediateSamples=i;
            break;

        case DMA_ENABLE:
#if TRACE_READ
            printk(KERN_ERR GSC_NAME "(%d): DMA starting addr %p to transfer %d\n", device->minor,device->dma_data[RX].intermediateBuffer,nToTransfer);
            memset(device->dma_data[RX].intermediateBuffer,0x55, DMA_ORDER*PAGE_SIZE);
#endif
            if (device_read_dma(device, nToTransfer,DMA_ENABLE)!=0)
            {
#ifdef TRACE_READ
                printk(KERN_ERR GSC_NAME "(%d): Filldma_data[RX].intermediateBuffer - device_read_dma failure\n", device->minor);
#endif
                up (&device->sem);
                return (-EAGAIN);
            };
            break;

        case DMA_DEMAND_MODE:
            // already in the intermediate buffer.
            break;

        default: // invalid state
            up (&device->sem);
            return (-EIO);
            break;
    }

    up (&device->sem);
    return nToTransfer;

} // Filldma_data[RX].intermediateBuffer

/************************************************************************/
/* device_read_dma                                                      */
/************************************************************************/
/* fill the buffer using the DMA method */
/* by the time this is called, we know that we have enough samples in the FIFO */
static int device_read_dma(struct device_board *device, u32 nRequested, int DMAMode)
{
    u32 regval;
#ifdef TRACE_READ
    int q;
    printk(KERN_INFO GSC_NAME "(%d): device_read_dma()\n", device->minor);
    memset(device->dma_data[RX].intermediateBuffer,0x51, DMA_ORDER*PAGE_SIZE);
    //regdump(device,"start of dma read");
    for (q=0;q<=12;q++)
    {
        printk("%.8X ",device->dma_data[RX].intermediateBuffer[q]);
    }
    printk("\n----------------------------------\n");
    //regdump(device);
#endif

    atomic_set(&device->irq_event_pending[EVENT_DMA_PENDING],TRUE);
    EnableIrqPlxDMA(device);
    device->timeout=FALSE;
    device->watchdog_timer.expires=jiffies+device->timeout_seconds*HZ;

    writel(NON_DEMAND_DMA_MODE, DMAMode0(device));
    writel(device->dma_data[RX].intermediatePhysicalAddr, DMAPCIAddr0(device));
    writel((ANALOG_INPUT_REG << 2), DMALocalAddr0(device));
    writel((nRequested << 2), DMAByteCnt0(device));
    writel(0xA, DMADescrPtr0(device));
    writel(0, DMAArbitr(device));
    writel(0, DMAThreshold(device));
    regval = readl(DMACmdStatus(device));
    regval &= STOP_DMA_CMD_0_MASK;
    writel(regval, DMACmdStatus(device));
    // OK, here we go! 
    regval = readl(DMACmdStatus(device));
    regval |= SETUP_DMA_CMD_0;
    writel(regval, DMACmdStatus(device));
    regval |= STARTUP_DMA_CMD_0;
    writel(regval, DMACmdStatus(device));
#if TRACE_READ
    printk(KERN_INFO GSC_NAME "(%d): device_read_dma - about to start dma...\n", device->minor);
    writel(0xeeeeeeee, (Mailbox0(device)));
//    regdump(device);
#endif

    add_timer(&device->watchdog_timer);
    device->debug_state=1;
#if TRACE_READ
    printk(KERN_INFO GSC_NAME "(%d): device_read_dma - about to wait for dma... BCR: %.8X\n", device->minor,readlocal(device,BOARD_CTRL_REG));
    for (q=0;q<=12;q++)
    {
        printk("%.8X ",device->dma_data[RX].intermediateBuffer[q]);
    }
    printk("\n----------------------------------\n");
    //regdump(device);
#endif
    wait_event_interruptible(device->dmawq,(!atomic_read(&device->irq_event_pending[EVENT_DMA_PENDING])));
    device->debug_state=2;
    if (signal_pending(current)) {
        device->debug_state=3;
        printk(KERN_ERR GSC_NAME "(%d): device_read_dma - signal error...\n", device->minor);
        del_timer_sync(&device->watchdog_timer);
        DisableIrqPlx(device);
        return (-ERESTARTSYS); 
    }
    device->debug_state=4;

#if TRACE_READ
    writel(0xffffffff, (Mailbox0(device)));
    for (q=0;q<=12;q++)
    {
        printk("%.8X ",device->dma_data[RX].intermediateBuffer[q]);
    }
    printk("\n----------------------------------\n");
#endif

    if (device->timeout)
    {
        device->debug_state=5;
        printk(KERN_ERR GSC_NAME "(%d): device_read_dma - timeout...\n", device->minor);
#if TRACE_READ
        printk(" (%d): In progress: %d PLX int/ctrl %.8X BC %.8X DMA %.8X\n", device->minor,atomic_read(&device->irq_event_pending[EVENT_DMA_PENDING]), readl(IntCntrlStat(device)), readlocal(device,BOARD_CTRL_REG),readl(DMACmdStatus(device)));
#endif
        return (-EAGAIN);
    }
    else
    {
#if TRACE_READ
        printk(KERN_INFO GSC_NAME "(%d): device_read_dma - success...\n", device->minor);
#endif
        device->debug_state=6;
        del_timer_sync(&device->watchdog_timer);
        device->debug_state=7;
    }
    device->dma_data[RX].intermediateSamples=nRequested;

    return 0;
}
