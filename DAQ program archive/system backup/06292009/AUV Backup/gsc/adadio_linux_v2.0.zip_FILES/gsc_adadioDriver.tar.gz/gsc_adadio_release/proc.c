/***
***  proc.c
***
***  General description of this file:
***     Device driver source code for General Standards ADADIO
***     analog I/O board. This file is part of the Linux
***     driver source distribution for this board.
***
***     This file is not necessary to compile application programs, therefore
***     should NOT be included in binary only driver distributions.
***
***  Copyrights (c):
***     General Standards Corporation (GSC), Feb 2004
***
***  Author:
***     Evan Hillan (evan@generalstandards.com)
***
***  Support:
***     Primary support for this driver is provided by GSC. 
***
***  Platform (tested on, may work with others):
***     Linux, kernel version 2.4.18+, Red Hat distribution, Intel hardware.
***
***/

//////////////////////////////////////////////////////////////////////////
// set the following flag to trace debug messages in this module.
#ifdef DEBUG
//#define TRACE_PROC TRUE
#endif

//#define __NO_VERSION__
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/pci.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/ioctl.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include "sysdep.h"
#include "adadio_ioctl.h"
#include "internals.h"

#include "plx_regs.h"

/******************************************************************************
*
*   Function:   read_proc
*
*   Purpose:
*
*       Implement the read service for the module's /proc file system
*       entry. Read the documentation on this service for details, as
*       we ignore some arguments according to our needs and the
*       documentation.
*
*   Arguments:
*
*       page    The data produced is put here.
*
*       start   Records pointer to where the data in "page" begins.
*
*       offset  The offset into the file where we're to begin.
*
*       count   The limit to the amount of data we can produce.
*
*       eof Set this flag when we hit EOF.
*
*       data    A private data item that we may use, but don't.
*
*   Returned:
*
*       int The number of characters written.
*
******************************************************************************/
int read_proc(
                     char*  page,
                     char** start,
                     off_t  offset,
                     int    count,
                     int*   eof,
                     void*  data)
{
#define _PROC_MSG_SIZE  128

#if PAGE_SIZE < _PROC_MSG_SIZE
#error  "/proc file size may be too big."
#endif
    int i;
#ifdef TRACE_PROC
    int j;
    char    str[256];
#endif

    MOD_INC_USE_COUNT;
    i   = sprintf(page,
        "version: %s\n"
        "built: %s\n"
        "boards: %d\n",
        DRIVER_VERSION,
        built,
        num_boards);
    page[i] = 0;

#ifdef TRACE_PROC
    strcat(page, "Debug Stats:\n ");
    strcat(page,"type\tother_ints\ttotal_ints\tdma_ints\tchan_irq\tchan_expect\n");

    for(j=0;j<num_boards;j++){
        sprintf(str,"%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%p\n",
            board_type[j],
            int_other_count[j],
            int_count[j],
            dma_count[j],
            channel_irq[j],
            channel_expected[j],
            context[j]
            );
            strcat(page,str);
    }

#endif
    strcat(page, "\n");
    i   = strlen(page) + 1;

    if (i >= PAGE_SIZE) {
        printk(KERN_INFO GSC_NAME "/proc/xxx is larger than PAGE_SIZE\n");
        i= PAGE_SIZE-1;
    }

    i--;
    eof[0]  = 1;
    MOD_DEC_USE_COUNT;
    return(i);
}

/******************************************************************************
*
*   Function:   proc_get_info
*
*   Purpose:
*
*       Implement the get_info() service for /proc file system support.
*
*   Arguments:
*
*       page    The data produced is put here.
*
*       start   Records pointer to where the data in "page" begins.
*
*       offset  The offset into the file where we're to begin.
*
*       count   The limit to the amount of data we can produce.
*
*       dummy   A parameter that is unused (for kernel 2.2 only).
*
*   Returned:
*
*       int The number of characters written.
*
******************************************************************************/
int proc_get_info(
                  char* page,
                  char**    start,
                  off_t offset,
                  int   count,
                  int dummy)
{
    int eof;
    int i;

    i   = read_proc(page, start, offset, count, &eof, NULL);
    return(i);
}
