#include <asm/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <sys/ioctl.h>

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>

#include "adadio_ioctl.h"

char driver_name[80]="/dev/adadio\0";

#define WORDS_TO_SEND 10

#define BUFFER_SIZE 32*1024

//#define BUFFER_SIZE (1024*16)
//#define BUFFER_SIZE (1024*256)
#define BUFFER_BYTES (BUFFER_SIZE*sizeof(__u32))

// text names to describe each type of board supported. 
char *boards_supported[] = {
	"adadio",
		"NULL" 
};

// number of channels for each board supported. 

int channels[] = {
	12,
};

int main(int argc, char *argv[])
{
	struct register_params rw_q;
	unsigned long buffer[BUFFER_SIZE], total, count[16];
	int fd, res, i, print, nread;
	int board_type;
	unsigned long param;
    time_t startTime,lastDisplay=0,now,lapse;
    int bytesRead;
    int error_code=0;
    int buffersRead=0;
    int wordsRead=0;
    int passes=0;

	if (argc < 2) {
		printf("%s: missing argument\nusage: testapp [0|1|2|...]\n", argv[0]);
		return (1);
	}

	strcat(driver_name, argv[1]);
	printf("about to open %s\n",driver_name);

	fd = open(driver_name, O_RDWR);
	if (fd < 0) {
		printf("%s: can not open device %s\n", argv[0], driver_name);
		return (1);
	}
    init_keyboard();

	res = ioctl(fd, IOCTL_GSC_GET_DEVICE_TYPE, &board_type);
	if (res < 0) {
		printf("%s: ioctl IOCTL_GSC_GET_DEVICE_TYPE failed\n", argv[0]);
		goto OUT;
	}
	printf("open OK - board type: %s channels: %d\n", boards_supported[board_type],channels[board_type]);

	rw_q.eRegister = 0x0;
	rw_q.ulValue = 0x2000;
	res = ioctl(fd, IOCTL_GSC_READ_REGISTER, &rw_q);
	if (res < 0) {
		printf("%s: ioctl IOCTL_GSC_READ_REGISTER failed\n", argv[0]);
		goto OUT;
	}
	printf("before init: BCR is 0x%lx\n", rw_q.ulValue);

    // set timeout for init, autocal, read operations.

    param = 5;
    res = ioctl(fd,IOCTL_GSC_SET_TIMEOUT, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_SET_TIMEOUT failed\n", argv[0]);
        goto OUT;
    }

    res = ioctl(fd, IOCTL_GSC_INITIALIZE, NULL);
	if (res < 0) {
		printf("%s: ioctl IOCTL_GSC_INITIALIZE failed\n", argv[0]);
		goto OUT;
    }
	printf("board init OK\n");

	rw_q.eRegister = 0x0;
	rw_q.ulValue = 0x2000;
	res = ioctl(fd, IOCTL_GSC_READ_REGISTER, &rw_q);
	if (res < 0) {
		printf("%s: ioctl IOCTL_GSC_READ_REGISTER failed\n", argv[0]);
		goto OUT;
	}
	printf("after init: BCR is 0x%lx\n", rw_q.ulValue);

	res = ioctl(fd, IOCTL_GSC_CALIBRATE, NULL);
	if (res < 0) {
		printf("%s: ioctl IOCTL_GSC_CALIBRATE failed %d\n", argv[0],i);
		goto OUT;
	}

	printf("auto calibration OK\n");

    // clear the input buffer.

    res = ioctl(fd, IOCTL_GSC_CLEAR_BUFFER, NULL);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_CLEAR_BUFFER failed %d\n", argv[0],i);
        goto OUT;
    }

	//	set the analog input to single-ended burst mode.
	
	param = SINGLE_ENDED_CONTINUOUS;
	res = ioctl(fd,IOCTL_GSC_CONFIG_INPUTS, &param);
	if (res < 0) {
		printf("%s: ioctl IOCTL_GSC_CONFIG_INPUTS failed\n", argv[0]);
		goto OUT;
	}
	
    //	two's comp data format.

    param = FORMAT_TWOS_COMPLEMENT;
    res = ioctl(fd, IOCTL_GSC_SET_DATA_FORMAT, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_SELECT_DATA_FORMAT failed\n", argv[0]);
        goto OUT;
    }

    //	Set the size of the input buffer.

    param = BUF_SIZE_256;
    res = ioctl(fd, IOCTL_GSC_SET_INPUT_BUFFER_SIZE, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_SET_INPUT_BUFFER_SIZE failed\n", argv[0]);
        goto OUT;
    }

    //	Enable the outputs.

    param = TRUE;
    res = ioctl(fd, IOCTL_GSC_ENABLE_OUTPUTS, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_ENABLE_OUTPUTS failed\n", argv[0]);
        goto OUT;
    }

    //	Set the DIO to outputs.

    param = DIO_DIR_OUTPUT;
    res = ioctl(fd, IOCTL_GSC_SET_DIO_DIR, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_SET_DIO_DIR failed\n", argv[0]);
        goto OUT;
    }

    //	Set the DIO outputs to all ones.

    param = 0xff;
    res = ioctl(fd, IOCTL_GSC_SET_DIO, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_SET_DIO failed\n", argv[0]);
        goto OUT;
    }

    //	Write a value to one of the analog output registers.

    param = 0x0ff0;
    res = ioctl(fd, IOCTL_GSC_WRITE_ANALOG_0, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_WRITE_ANALOG_0 failed\n", argv[0]);
        goto OUT;
    }

    //	Set the data sampling rate.

    param = 0xc9; // 99,502 samples per second, per hardware manual
    res = ioctl(fd, IOCTL_GSC_SET_NRATE, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_SET_NRATE failed\n", argv[0]);
        goto OUT;
    }

    //	Select DMA or PIO data transfers.

//    param = DMA_DISABLE; 
    param = DMA_ENABLE; 
    res = ioctl(fd, IOCTL_GSC_SET_DMA_MODE, &param);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_SET_DMA_MODE failed\n", argv[0]);
        goto OUT;
    }

    total=0;
    startTime=time(NULL);
    /*******************************************/
    printf("Starting main loop...press any key to exit...\n");
    
    while (!kbhit()) {

        // size of read is in bytes.

        memset(buffer,0xbaaaaaab,sizeof(buffer));
        bytesRead = read(fd, buffer, BUFFER_BYTES);
        buffersRead++;
        //      printf("read: %X\n",numread);
        if (bytesRead < 0){
            printf("\nread error -> after read...res = %d\n",bytesRead);
            goto OUT;
        }

        wordsRead = bytesRead / sizeof (long);
        total += wordsRead;
        passes++;

        now=time(NULL);
        if (now != lastDisplay)
        {
            lastDisplay=now;
            print = (total >> 20);
            {
                int j;
                lapse = time(NULL)-startTime;
                if (lapse != 0 )
                {
                    printf ("seconds: %.8d Minutes: %d Words read: %.8x samples/sec: %.8ld - ",lapse, lapse/60, wordsRead, total/lapse);
                    j=0;
                }
            }
            printf("      \r");
            fflush(stdout);
        }
    }

    printf("\n Total samples: %ld ",total);

OUT:
    close_keyboard();
    printf("\n\n");
    fflush(stdout);

    // read the last hardware/driver error.

    res = ioctl(fd, IOCTL_GSC_GET_DEVICE_ERROR, &error_code);
    if (res < 0) {
        printf("%s: ioctl IOCTL_GSC_GET_DEVICE_ERROR failed\n", argv[0]);
        return (1);
    }
    printf("\n Last error code: %d\n",error_code);

    close(fd);

    return 0;
}
